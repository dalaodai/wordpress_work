(function($) {
  "use strict";


})(jQuery);